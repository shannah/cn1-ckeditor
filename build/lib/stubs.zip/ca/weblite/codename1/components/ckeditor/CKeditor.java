package ca.weblite.codename1.components.ckeditor;


/**
 * 
 *  @author shannah
 */
public class CKeditor extends com.codename1.ui.Container {

	public CKeditor() {
	}

	public void initLater(Runnable afterInit) {
	}

	public void initLater() {
	}

	public void initAndWait() {
	}

	public Exception getInitializationException() {
	}

	public void setData(String content, Runnable callback, boolean internal) {
	}

	public void setData(String content, Runnable callback) {
	}

	public void setData(String content) {
	}

	public String getData() {
	}

	public void insertHtml(String html) {
	}

	public void insertText(String text) {
	}

	public void addCss(String css) {
	}

	public boolean checkDirty() {
	}

	public void resetDirty() {
	}

	public void setReadOnly(boolean readonly) {
	}
}
